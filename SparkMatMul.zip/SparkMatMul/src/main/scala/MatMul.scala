import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object Multiply {

  def main ( args: Array[String] ) {
    val conf = new SparkConf().setAppName("Multiply")
    val sc = new SparkContext(conf)

    conf.set("spark.logConf","false")
    conf.set("spark.eventLog.enabled","false")


  
    sc.stop()

  }
}

